import { useEffect, useState } from 'react';
import { View, Text, TextInput, StyleSheet, ActivityIndicator, Pressable, Image, ScrollView, Alert } from 'react-native';
import DropDownPicker from 'react-native-dropdown-picker';
import DateTimePicker from '@react-native-community/datetimepicker';
import * as ImagePicker from 'expo-image-picker';
import { collection, getDocs, addDoc, Timestamp } from 'firebase/firestore';
import { db, auth } from '../../firebaseConfig';
import { Ionicons } from '@expo/vector-icons';


export default function SellScreen() {
  const [cat1Open, setCat1Open] = useState(false);
  const [cat2Open, setCat2Open] = useState(false);
  const [cat1Items, setCat1Items] = useState<any[]>([]);
  const [cat2Items, setCat2Items] = useState<any[]>([]);
  const [cat1Value, setCat1Value] = useState(null);
  const [cat2Value, setCat2Value] = useState(null);
  const [loading, setLoading] = useState(true);
  const [allCat2Items, setAllCat2Items] = useState<any[]>([]);
  const [images, setImages] = useState<string[]>([]);

  const [form, setForm] = useState<{
    name: string;
    description: string;
    location: string;
    startPrice: string;
    startTime: Date;
    endTime: Date;
    images: string[]; // <-- array of image URIs
  }>({
    name: '',
    description: '',
    location: '',
    startPrice: '',
    startTime: new Date(),
    endTime: new Date(),
    images: [],
  });
  
  

  const fetchCategories = async () => {
    try {
      const cat1Snap = await getDocs(collection(db, 'product_cat1'));
      const cat2Snap = await getDocs(collection(db, 'product_cat2'));
      setCat1Items(cat1Snap.docs.map(doc => ({ label: doc.data().label, value: doc.id })));
      setAllCat2Items(cat2Snap.docs.map(doc => ({
        label: doc.data().label,
        value: doc.id,
        parentCat1Id: doc.data().parentCat1Id
      })));
      
    } catch (err) {
      console.error('Error loading categories:', err);
    } finally {
      setLoading(false);
    }
  };

  const pickImages = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        allowsMultipleSelection: true,
        mediaTypes: 'images',
        quality: 0.7,
      });
  
      if (!result.canceled && result.assets?.length) {
        const selectedImages = result.assets.map((asset) => asset.uri);
        setImages(selectedImages);
        setForm(prev => ({ ...prev, images: selectedImages }));

      }
    } catch (error) {
      Alert.alert('Error', 'Failed to pick images');
    }
  };

  const handleSubmit = async () => {
    if (
  !form.name ||
  !form.description ||
  !form.location ||
  !cat1Value ||
  !cat2Value ||
  !form.images ||
  form.images.length === 0
) {
  return Alert.alert('Missing fields', 'Please fill in all required fields and select at least one image.');


    }

    try {
      await addDoc(collection(db, 'products'), {
        ...form,
        cat1Id: cat1Value,
        cat2Id: cat2Value,
        photos: form.images,
        status: 'pending',
        userId: auth.currentUser?.uid,
        createdAt: Timestamp.now(),
        startPrice: Number(form.startPrice),
        startTime: Timestamp.fromDate(new Date(form.startTime)),
        endTime: Timestamp.fromDate(new Date(form.endTime)),
      });
      Alert.alert('Success', 'Bid created and pending approval');
      setForm({
        name: '',
        description: '',
        location: '',
        startPrice: '',
        startTime: new Date(),
        endTime: new Date(),
        images: [],
      });
      setImages([]);
    } catch (err) {
      console.error(err);
      Alert.alert('Error', 'Failed to submit bid');
    }
  };

  useEffect(() => {
    if (cat1Value) {
      const filtered = allCat2Items.filter(item => item.parentCat1Id === cat1Value);
      setCat2Items(filtered);
    } else {
      setCat2Items([]);
    }
  }, [cat1Value, allCat2Items]);
  
  useEffect(() => {
    fetchCategories();
  }, []);

  if (loading) return <ActivityIndicator color="#10a37f" size="large" style={{ flex: 1 }} />;

  return (
    
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 80 }}>
      <View style={styles.imageUploadBox}>
  <Pressable onPress={pickImages} style={styles.imageUploadContent}>
    {images.length === 0 ? (
      <>
        <Ionicons name="add" size={32} color="#10a37f" />
        <Text style={styles.imageUploadText}>Choose Images</Text>
      </>
    ) : (
      <Image source={{ uri: images[0] }} style={styles.mainPreview} />
    )}
  </Pressable>
</View>

      <Text style={styles.title}>Create a Bid</Text>

      <TextInput style={styles.input} placeholder="Location" placeholderTextColor="#aaa" value={form.location} onChangeText={t => setForm({ ...form, location: t })} />
      <TextInput style={styles.input} placeholder="Name" placeholderTextColor="#aaa" value={form.name} onChangeText={t => setForm({ ...form, name: t })} />
      <TextInput style={[styles.input, { height: 100 }]} placeholder="Description" placeholderTextColor="#aaa" multiline value={form.description} onChangeText={t => setForm({ ...form, description: t })} />
      <TextInput style={styles.input} placeholder="Starting Price" placeholderTextColor="#aaa" keyboardType="numeric" value={form.startPrice} onChangeText={t => setForm({ ...form, startPrice: t })} />
<View style={{ zIndex: 1000, marginBottom: 20 }}>
      <DropDownPicker
  open={cat1Open}
  setOpen={setCat1Open}
  value={cat1Value}
  setValue={setCat1Value}
  items={cat1Items}
  setItems={setCat1Items}
  placeholder="Select Category"
  style={styles.dropdown}
  textStyle={{ color: '#fff' }}              // 👈 ensures dropdown text is white
  dropDownContainerStyle={styles.dropdownContainer}
/>
</View>
<View style={{ zIndex: 500 }}>
      <DropDownPicker
        open={cat2Open}
        setOpen={setCat2Open}
        value={cat2Value}
        setValue={setCat2Value}
        items={cat2Items}
        setItems={setCat2Items}
        placeholder="Select Subcategory"
        style={styles.dropdown}
        textStyle={{ color: '#fff' }}              // 👈 ensures dropdown text is white
        dropDownContainerStyle={styles.dropdownContainer}
      />
</View>
      <Text style={styles.label}>Start Time</Text>
      <TextInput style={styles.input} value={form.startTime.toISOString()} editable={false} />
      <Text style={styles.label}>End Time</Text>
      <TextInput style={styles.input} value={form.endTime.toISOString()} editable={false} />

      <Pressable style={styles.submitBtn} onPress={handleSubmit}>
        <Text style={styles.submitText}>Submit Bid</Text>
      </Pressable>
    </ScrollView>
  );
}
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0e0e10', padding: 20 },
  title: { fontSize: 22, fontWeight: '700', color: '#fff', marginBottom: 20 },
  input: {
    backgroundColor: '#1e1e1e', color: '#fff', fontSize: 16, padding: 12,
    borderRadius: 8, marginBottom: 14,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
  },
  dropdown: {
    marginBottom: 20,
    backgroundColor: '#1c1c1e',
    borderColor: '#333',
    zIndex: 1000, // Important if they overlap
  },
  imageUploadBox: {
    height: 160,
    backgroundColor: '#1c1c1e',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  imageUploadContent: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  imageUploadText: {
    color: '#aaa',
    marginTop: 8,
    fontSize: 14,
  },
  mainPreview: {
    width: 140,
    height: 140,
    borderRadius: 8,
    resizeMode: 'cover',
  },
  
  dropdownContainer: {
    backgroundColor: '#1c1c1e',
    borderColor: '#333',
    zIndex: 999, // Important if they overlap
  },
  

  label: { color: '#aaa', marginBottom: 6 },
  imageButton: {
    backgroundColor: '#333', padding: 12, borderRadius: 8, alignItems: 'center', marginBottom: 12,
  },
  preview: {
    width: '100%', height: 160, borderRadius: 8, marginBottom: 16,
  },
  submitBtn: {
    backgroundColor: '#10a37f', padding: 16, borderRadius: 8, alignItems: 'center',
  },
  submitText: {
    color: '#fff', fontSize: 16, fontWeight: '600',
  },
});
