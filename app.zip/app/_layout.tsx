import { Stack } from 'expo-router';
import { onAuthStateChanged } from 'firebase/auth';
import { auth } from '../firebaseConfig';
import { useEffect, useState } from 'react';
import { View, ActivityIndicator } from 'react-native';
import { router } from 'expo-router';
export default function RootLayout() {
  const [user, setUser] = useState<null | object | undefined>(undefined);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (firebaseUser) => {
      setUser(firebaseUser);
    });
    return unsubscribe;
  }, []);
  
  console.log("🔥 AUTH STATE NOW:", user);
  

  if (user === undefined) {
    console.log("🔥 Still loading user...");
    return (
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <ActivityIndicator size="large" color="#10a37f" />
      </View>
    );
    
  }
  console.log('Auth state:', user)
  return (
    <Stack screenOptions={{ headerShown: false }}>
      {user ? (
        <Stack.Screen name="(tabs)/home" />
      ) : (
        <Stack.Screen name="auth" />
      )}
    </Stack>
  );  
}
